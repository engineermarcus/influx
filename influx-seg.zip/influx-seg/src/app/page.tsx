'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { Header } from '@/components/Header';
import { UploadZone } from '@/components/UploadZone';
import { FramePanel } from '@/components/FramePanel';
import { FullscreenFrame } from '@/components/FullscreenFrame';
import { ActionBar } from '@/components/ActionBar';
import { Gallery } from '@/components/Gallery';
import { TabBar } from '@/components/TabBar';
import { Toast } from '@/components/Toast';
import { api } from '@/lib/api';
import { downloadDataUrl } from '@/lib/coords';
import type { FrameKey } from '@/lib/types';

export default function Home() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [inputImage, setInputImage] = useState<string | null>(null); // full data URL
  const [coverageImage, setCoverageImage] = useState<string | null>(null); // base64
  const [recomposedImage, setRecomposedImage] = useState<string | null>(null); // base64
  const [gallery, setGallery] = useState<string[]>([]);
  const [segmenting, setSegmenting] = useState(false);
  const [activeTab, setActiveTab] = useState<FrameKey>('input');
  const [fullscreenFrame, setFullscreenFrame] = useState<Extract<FrameKey, 'input' | 'coverage'> | null>(null);

  const [toastMsg, setToastMsg] = useState('');
  const [toastErr, setToastErr] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const toast = useCallback((msg: string, isErr = false, ms = 2800) => {
    setToastMsg(msg);
    setToastErr(isErr);
    setToastVisible(true);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastVisible(false), ms);
  }, []);

  const initSession = useCallback(async () => {
    try {
      const d = await api.createSession();
      setSessionId(d.session_id);
    } catch {
      toast('Could not reach the backend. Is it running?', true, 5000);
    }
  }, [toast]);

  useEffect(() => {
    initSession();
  }, [initSession]);

  const dataUrl = (b64?: string | null) => (b64 ? `data:image/png;base64,${b64}` : null);

  const handleFile = useCallback(
    async (file: File) => {
      if (!sessionId) return;
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const full = ev.target?.result as string;
        try {
          const d = await api.upload(sessionId, full);
          if (d.error) {
            toast(d.error, true);
            return;
          }
          setInputImage(full);
          setCoverageImage(d.coverage ?? null);
          setRecomposedImage(null);
          setGallery([]);
          setActiveTab('input');
          toast(`Image loaded · ${d.width}×${d.height}px`);
        } catch (err) {
          toast('Upload failed: ' + (err as Error).message, true);
        }
      };
      reader.readAsDataURL(file);
    },
    [sessionId, toast]
  );

  const applySegmentResult = useCallback((d: { coverage?: string; recomposed?: string | null; gallery?: string[] }) => {
    if (d.coverage) setCoverageImage(d.coverage);
    setRecomposedImage(d.recomposed ?? null);
    setGallery(d.gallery ?? []);
  }, []);

  const handleSegment = useCallback(
    async (x: number, y: number) => {
      if (!sessionId) return;
      setSegmenting(true);
      try {
        const d = await api.segment(sessionId, x, y);
        if (d.error) {
          toast(d.error, true);
          return;
        }
        applySegmentResult(d);
        toast(`Layer ${d.layer_count ?? gallery.length + 1} added`);
      } catch (err) {
        toast('Segment failed: ' + (err as Error).message, true);
      } finally {
        setSegmenting(false);
      }
    },
    [sessionId, applySegmentResult, toast, gallery.length]
  );

  const handleRemove = useCallback(
    async (x: number, y: number) => {
      if (!sessionId) return;
      try {
        const d = await api.remove(sessionId, x, y);
        if (d.error) {
          toast(d.error, true);
          return;
        }
        applySegmentResult(d);
        toast('Layer removed');
      } catch (err) {
        toast('Remove failed: ' + (err as Error).message, true);
      }
    },
    [sessionId, applySegmentResult, toast]
  );

  const handleClear = useCallback(async () => {
    if (!sessionId) return;
    const d = await api.clear(sessionId);
    applySegmentResult(d);
    toast('All layers cleared');
  }, [sessionId, applySegmentResult, toast]);

  const handleRecompose = useCallback(async () => {
    if (!sessionId) return;
    const d = await api.recompose(sessionId);
    if (d.recomposed) {
      setRecomposedImage(d.recomposed);
      toast('Recomposed!');
    } else {
      toast('Nothing to recompose yet', true);
    }
  }, [sessionId, toast]);

  const handleDownload = useCallback(() => {
    if (!recomposedImage) return;
    downloadDataUrl(dataUrl(recomposedImage)!, `recomposed-${Date.now()}.png`);
    toast('Download started');
  }, [recomposedImage, toast]);

  const resetAll = useCallback(() => {
    setInputImage(null);
    setCoverageImage(null);
    setRecomposedImage(null);
    setGallery([]);
    setActiveTab('input');
    setFullscreenFrame(null);
    initSession().then(() => toast('Ready for a new image'));
  }, [initSession, toast]);

  const hasImage = !!inputImage;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 w-full max-w-[1400px] mx-auto px-4 sm:px-7 py-5 sm:py-6">
        {!hasImage && <UploadZone onFile={handleFile} />}

        {hasImage && (
          <>
            <TabBar active={activeTab} onChange={setActiveTab} layerCount={gallery.length} />

            {/* Desktop: 3-panel grid. Mobile: single active tab. */}
            <div className="hidden sm:grid grid-cols-3 gap-3.5 mb-5">
              <FramePanel
                frameKey="input"
                src={inputImage}
                busy={segmenting}
                canFullscreen
                onExpand={() => setFullscreenFrame('input')}
                onClickPoint={handleSegment}
                cursorStyle="crosshair"
              />
              <FramePanel
                frameKey="coverage"
                src={dataUrl(coverageImage)}
                canFullscreen
                onExpand={() => setFullscreenFrame('coverage')}
                onClickPoint={handleSegment}
                cursorStyle="crosshair"
              />
              <FramePanel
                frameKey="recomposed"
                src={dataUrl(recomposedImage)}
                onClickPoint={handleRemove}
                cursorStyle="cell"
              />
            </div>

            <div className="sm:hidden mb-5">
              {activeTab === 'input' && (
                <FramePanel
                  frameKey="input"
                  src={inputImage}
                  busy={segmenting}
                  canFullscreen
                  onExpand={() => setFullscreenFrame('input')}
                  onClickPoint={handleSegment}
                  cursorStyle="crosshair"
                />
              )}
              {activeTab === 'coverage' && (
                <FramePanel
                  frameKey="coverage"
                  src={dataUrl(coverageImage)}
                  canFullscreen
                  onExpand={() => setFullscreenFrame('coverage')}
                  onClickPoint={handleSegment}
                  cursorStyle="crosshair"
                />
              )}
              {activeTab === 'recomposed' && (
                <FramePanel
                  frameKey="recomposed"
                  src={dataUrl(recomposedImage)}
                  onClickPoint={handleRemove}
                  cursorStyle="cell"
                />
              )}
            </div>

            <ActionBar
              layerCount={gallery.length}
              hasRecomposed={!!recomposedImage}
              onRecompose={handleRecompose}
              onDownload={handleDownload}
              onClear={handleClear}
              onReset={resetAll}
              showReset={hasImage}
            />

            <Gallery layers={gallery} />
          </>
        )}
      </main>

      {fullscreenFrame && (
        <FullscreenFrame
          frameKey={fullscreenFrame}
          src={fullscreenFrame === 'input' ? inputImage : dataUrl(coverageImage)}
          busy={segmenting}
          onClickPoint={handleSegment}
          onExit={() => setFullscreenFrame(null)}
          hudSrc={dataUrl(recomposedImage)}
        />
      )}

      <Toast message={toastMsg} isError={toastErr} visible={toastVisible} />
    </div>
  );
}
